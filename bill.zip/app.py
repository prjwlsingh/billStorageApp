"""

task list:
    1. Start server
    2. Make class for sql database
    3. write get and post API definitions

"""

from flask import *
import json
import sqlite3
from bill import Bill
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# create db
def create_db():
    c = sqlite3.connect("bill.db").cursor()
    c.execute("CREATE TABLE IF NOT EXISTS BILL("
              "id TEXT, title TEXT, description TEXT, tag TEXT, created_at TEXT, userId TEXT)"
              )
    c.execute("CREATE TABLE IF NOT EXISTS USER("
              "userId TEXT)"
              )
    c.connection.close()

@app.route('/', methods=['GET'])
def create_db():
    create_db()
    return 'bill and user DB created'

"""
there are 4 app routes
1. retrieve list of user bills
2. post image 
3. retrieve bill using bill id
4. create bill to put in db


"""

# get list of user bills from db
@app.route('/getUserBill', methods=['GET'])
def get_userBills(userId):
    c = sqlite3.connect("bill.db").cursor()
    c.execute("SELECT * FROM BILL WHERE userId=?", userId)
    data = c.fetchall()
    return jsonify(data)



# get a bill with particular bill id
@app.route('/getBill', methods=['GET'])
def get_bill(billId):
    c = sqlite3.connect("bill.db").cursor()
    c.execute("SELECT * FROM BILL WHERE billId=?", billId)
    data = c.fetchall()
    return jsonify(data)



# post bill into db
@app.route('/createBill', methods=['POST','GET'])
def create_bill(payload):
    db = sqlite3.connect("bill.db")



    c = db.cursor()

    

# post image to cloud
@app.route('/postImage', methods=['POST', 'GET'])
def post_image(payload):
    db = sqlite3.connect("bill.db")
    c = db.cursor()




#server

if __name__ == '__main__':
    app.run(port=8888)
